
#
#      Copyright (C) 2013 Sean Poyser
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import urllib
import urllib2
import random
import re
import os

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui

import resolve

ADDONID = 'plugin.video.watchcartoononline'
ADDON   = xbmcaddon.Addon(ADDONID)
HOME    = ADDON.getAddonInfo('path')
ARTWORK = os.path.join(HOME, 'resources', 'artwork')
ICON    = os.path.join(HOME, 'icon.png')
TITLE   = 'Watch Cartoon Online'
VERSION = '1.0.0'
URL     = 'http://www.watchcartoononline.com/'


SECTION  = 100
SERIES   = 200
EPISODE  = 300


def CheckVersion():
    prev = ADDON.getSetting('VERSION')
    curr = VERSION

    if prev == curr:
        return

    ADDON.setSetting('VERSION', curr)

    if curr == '1.0.0':
        d = xbmcgui.Dialog()
        d.ok(TITLE + ' - ' + VERSION, '', 'Welcome to Watch Cartoon Online', '')


def Clean(text):
    text = text.replace('&#8211;', '-')
    text = text.replace('&#8230;', '...')
    text = text.replace('&#215;',  'x')

    text = text.replace('&#8217;', '\'')
    text = text.replace('&#8220;', '"')
    text = text.replace('&#8221;', '"')
    text = text.replace('&#39;',   '\'')
    text = text.replace('<b>',     '')
    text = text.replace('</b>',    '')
    text = text.replace('&amp;',   '&')
    text = text.replace('\ufeff', '')
    return text


def GetHTML(url, useCache = True):
    if useCache:
        html, cached = geturllib.GetURL(url, 86400)
    else:
        html = geturllib.GetURLNoCache(url)

    html  = html.replace('\n', '')
    return html


def Main():
    CheckVersion()

    html = GetHTML(URL)

    match = re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(html)
    for url, name in match:
        if name == 'Contact':
            break
        if name != 'Home':
            AddSection(name, '', url)


def DoSection(url):
    mode = SERIES
    if url == 'http://www.watchcartoononline.com/movie-list':
        mode = EPISODE
    if url == 'http://www.watchcartoononline.com/ova-list':
        mode = EPISODE

    html = GetHTML(url)

    if '009-1</a>' in html:
        html = html.split('009-1</a>')[-1]
    else:
        html = html.split('_"></a>')[-1]
    html = html.replace('<li><a href=""></a></li>', '')
  
    names = []

    match = re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(html)
    for url, name in match:
        if ('#' not in url) and ('title="' not in url):
            if name not in names:
                names.append(name)
                if mode == SERIES:
                    AddSeries(name, url)
                elif mode == EPISODE:
                    AddEpisode(name, url)


def DoSeries(url):
    html = GetHTML(url)
    #main = re.compile('<title>(.+?) \| .+?').search(html).group(1)
    html = html.split('animelist', 1)[-1]

    match = re.compile('<a href=(.+?)<div class="ildate">').findall(html)

    for item in match:
        name = None
        url  = None
        try:
            match1 = re.compile('<a href="(.+?)".+?title=".+?">(.+?)</a>').findall(item)
            url    = match1[0][0]
            name   = match1[0][1]
        except:
            match1 = re.compile('"(.+?)".+?title=".+?">(.+?)</a>').findall(item)
            url    = match1[0][0]
            name  = match1[0][1]

        if name and url:
            AddEpisode(name, url)

    if 'Previous Entries' in html:
        url = re.compile('<div class="alignleft"><a href="(.+?)".+?Previous Entries</a>').search(html).group(1)
        AddSeries('More...', url)


def PlayVideo(_url):
    #print _url
    url, msg = resolve.ResolveURL(_url)
    if not url:
        d = xbmcgui.Dialog()
        d.ok(TITLE + ' - ' + VERSION, '', msg, '')

        print 'WATCHCARTOONSONLINE - (%s) Failed to locate video for %s' % (msg, _url)
        return

    html  = GetHTML(_url)
    image = re.compile('"image_src" href="(.+?)"').search(html).group(1)
    title = re.compile('<title>(.+?)</title>').search(html).group(1).split(' |', 1)[0]

    #print title
    #print image

    liz = xbmcgui.ListItem(title, iconImage=image, thumbnailImage=image)

    liz.setInfo( type="Video", infoLabels={ "Title": title} )
    liz.setProperty("IsPlayable","true")

    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    pl.add(url, liz)
    xbmc.Player().play(pl)


def AddEpisode(name, url):
    AddDir(name, EPISODE, url, isFolder=False)


def AddSeries(name, url):
    AddDir(name, SERIES, url)


def AddSection(name, image, url):
    if image == '':
        image = ICON
    else:
        image=os.path.join(ARTWORK, image+'.png')

    AddDir(name, SECTION, url, image, isFolder=True)


def AddDir(name, mode, url='', image=None, isFolder=True, page=1, keyword=None, infoLabels=None, contextMenu=None):
    name = Clean(name)

    if not image:
        image = ICON

    u  = sys.argv[0] 
    u += '?mode='  + str(mode)
    u += '&title=' + urllib.quote_plus(name)
    u += '&image=' + urllib.quote_plus(image)
    u += '&page='  + str(page)

    if url != '':     
        u += '&url='   + urllib.quote_plus(url) 

    if keyword:
        u += '&keyword=' + urllib.quote_plus(keyword) 

    liz = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)

    if contextMenu:
        liz.addContextMenuItems(contextMenu)

    if infoLabels:
        liz.setInfo(type="Video", infoLabels=infoLabels)

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
    

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
           params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param


try:
    from xbmcads import ads
    ads.ADDON_ADVERTISE(ADDONID)
except:
    pass

import geturllib
geturllib.SetCacheDir(xbmc.translatePath(os.path.join('special://profile', 'addon_data', ADDONID ,'cache')))

params = get_params()
mode   = None
url    = None

try:    mode = int(urllib.unquote_plus(params['mode']))
except: pass

try:    url  = urllib.unquote_plus(params['url'])
except: pass


if mode == SECTION:
    DoSection(url)

elif mode == SERIES:
    DoSeries(url)

elif mode == EPISODE:
    PlayVideo(url)

else:
    Main()

        
try:
    #xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
except:
    pass
