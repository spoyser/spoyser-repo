
#
#      Copyright (C) 2013 Sean Poyser
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import geturllib
import urllib
import re

import xbmcaddon
import os


def GetHTML(url, useCache = True):
    if useCache:
        html, cached = geturllib.GetURL(url, 86400)
    else:
        html = geturllib.GetURLNoCache(url)

    html  = html.replace('\n', '')
    return html


def ResolveURL(url):
    print url
    #url = 'http://www.watchcartoononline.com/axis-powers-hetalia-episode-46-english-subbed' #vweed, multiple sources
    #url = 'http://www.watchcartoononline.com/halo-legends-episode-8-english-dubbed' #veoh
    #url = 'http://www.watchcartoononline.com/american-dad-season-1-episode-20-roger-n-me'#cizgifilmlerizle
    #url = 'http://www.watchcartoononline.com/adventures-of-sonic-the-hedgehog-episode-66-sonic-christmas-blast' #Youtube
    #url = 'http://www.watchcartoononline.com/tmnt-season-7-episode-13-wedding-bells-and-bytes #Youtube 2 PARS
    #url = 'http://www.watchcartoononline.com/thundercats-2011-premiere' #movieweb
    #postTabs_divs

    html = GetHTML(url)

    if 'movieweb' in html:
        return ResolveMovieweb(html)

    if 'youtube' in html:
        return ResolveYouTube(html)

    if 'veoh' in html:
        return ResolveVeoh(html)

    if 'vweed' in html:
        return ResolveVWeed(html)

    try:    
        html = html.split('.flv',   1)[0]
        html = html.rsplit('src="', 1)[-1]
        url  = html + '.flv'

        url = url.split('"')[0]

        if 'cizgifilmlerizle' in url:
            return Resolve(url)

        if 'animeuploads' in url:
            return Resolve(url)
    except:
        pass

    return None, 'Unidentified Resolver'


def Resolve(url):
    ret  = None
    text = ''
    try:
        from t0mm0.common.net import Net
        net = Net()

        data = {'fuck_you' : '', 'confirm' : 'Click+Here+to+Watch+Free%21%21'}
        url  = url.replace(' ', '%20')

        net.set_user_agent('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')

        html  = net.http_POST(url, data).content

        match = re.compile('file=(.+?)\'/>').search(html).group(1).split('file=', 1)[1].replace('&provider=http', '')

        url = urllib.unquote(match)
        url = url.replace(' ', '%20')
        ret = url       
    except:
        text = 'Error Resolving URL'

    return ret, text


def ResolveMovieweb(html):
    import json

    ret  = None
    text = ''
    try:
        id   = re.compile('http://www.movieweb.com/v/(.+?)"').search(html).group(1)
        url  = 'http://www.movieweb.com/v/%s/play?s=1&idx=0&e=1' % id
        html = GetHTML(url, useCache=False)
        
        jsn = json.loads(html)

        url = str(jsn['url_img']).split('.img', 1)[0]
        url += '/'
        url += jsn['videoId']
        url += '_'
        url += str(jsn['ii']) #might be i
        url += jsn['iii']
        url += '?'
        url += jsn['iiii']
        ret  = url
    except Exception, e:
        print str(e)
        raise
        text = 'Error Resolving Movieweb URL'

    return ret, text


def ResolveVeoh(html):
    ret  = None
    text = ''
    try:
        id   = re.compile('veoh.php\?v=(.+?)&').search(html).group(1)
        url  = 'http://www.veoh.com/rest/video/%s/details' % id
        html = GetHTML(url, useCache = False)
        ret  = re.compile('fullPreviewHashPath="(.+?)"').search(html).group(1)
    except:
        text = 'Error Resolving Veoh URL'

    return ret, text


def ResolveVWeed(html):
    return None, 'Unable to resolve VWeed hosted videos'
    #id   = re.compile('vweed.php\?vids=(.+?)&').search(html).group(1)   
    #url  = 'http://www.videoweed.es/file/%s' % id    
    

def ResolveYouTube(html):
    ret  = None
    text = ''
    try:
        if 'http://youtube.googleapis.com' in html:
            id  = re.compile('src="http://youtube.googleapis.com/v/(.+?)">').search(html).group(1)
        else:
            id  = re.compile('src="http://www.youtube.com/v/(.+?)">').search(html).group(1)

        id  = id.split('?', 1)[0]
        ret = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % id
    except:
        text = 'Error Resolving YouTube URL'

    if not CheckYouTube():
        ret  = None
        text = 'Please install YouTube addon'

    return ret, text

def CheckYouTube():
    try:
        yt    = 'plugin.video.youtube'
        path  = xbmcaddon.Addon(yt).getAddonInfo('path')
        if os.path.exists(path):
            return True
    except Exception, e:
        print str(e)
        pass

    return False