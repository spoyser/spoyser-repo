#
#      Copyright (C) 2013 Sean Poyser
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#


import urllib
import urllib2
import re
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import datetime
import time
import os
import display
import common
import random

ADDONID  = 'plugin.image.comicstrips'
ADDON    = xbmcaddon.Addon(ADDONID)
HOME     = ADDON.getAddonInfo('path')
TITLE    = 'Comic Strips'
VERSION  = '1.0.1'
URL      = 'http://www.gocomics.com'
ICON     =  os.path.join(HOME, 'icon.png')
#FANART   =  os.path.join(HOME, 'fanart.jpg')
ARTWORK = os.path.join(HOME, 'resources', 'artwork')


SECTION   = 100
CHARACTER = 200


def CheckVersion():
    prev = ADDON.getSetting('VERSION')
    curr = VERSION

    if prev == curr:
        return

    ADDON.setSetting('VERSION', curr)

    if curr == '1.0.0':
        d = xbmcgui.Dialog()
        d.ok(TITLE + ' - ' + VERSION, 'Welcome to Comic Strips', '' , 'Hope you enjoy [COLOR FFFF0000]:-)[/COLOR]')


def Clean(text):
    #text = text.replace('&#8211;', '-')
    #text = text.replace('&#8217;', '\'')
    #text = text.replace('&#8220;', '"')
    #text = text.replace('&#8221;', '"')
    #text = text.replace('&#39;',   '\'')
    #text = text.replace('<b>',     '')
    #text = text.replace('</b>',    '')
    text = text.replace('&#x27;', '\'')
    text = text.replace('&amp;',   '&')
    #text = text.replace('\ufeff', '')
    return text


def Main():
    CheckVersion()

    AddSection('Comics',              'comics')    
    AddSection('Political Cartoons',  'editorials')
    AddSection('Sherpa',              'sherpa')
    AddSection('Comics en Espanol',   'espanol')


def Section(url):
    url  = URL + '/explore/' + url
    html = common.GetHTML(url, timeout=43200) #1/2 a day
    #html = html.replace('a href="/explore', '') 

    match = re.compile('<li>(.+?)</li>').findall(html)

    for item in match:
        items = re.compile('<a href="(.+?)">.+?<img alt=".+?" class="thumb" height="60" src="(.+?)" title="(.+?)"').findall(item)
        url   = items[0][0]
        image = items[0][1].replace('tiny_avatar', 'avatar')
        name  = items[0][2]
        AddCharacter(name, url, image)


def Character(url):
    url  = GetFullURL(url)

    app = None
    try:
        app = display.Display(url)
        app.doModal()   
    except Exception, e:
        pass

    if app:
        del app


def GetFullURL(url):
    isCurrent = ADDON.getSetting('DISPLAY') == 'Current'

    if isCurrent:
        now = datetime.datetime.today()
        year  = now.year
        month = now.month
        day   = now.day
    else:
       #http://www.gocomics.com/calendar/wumo/2013/10
        year  = GetRandomYear( url)
        month = GetRandomMonth(url, year)
        day   = GetRandomDay(  url, year, month)

    print year
    print month
    print day

    url = '%s/%s/%d/%d/%d' % (URL, url, year, month, day)

    return url


def GetRandomYear(_url):
    now     = datetime.datetime.today()
    current = now.year

    years = range(2000, current+1)
    random.shuffle(years)
    
    for year in years:
        #check January
        url   = '%s/calendar%s/%d/1' % (URL, _url, year)
        resp  = eval(common.GetHTML(url))
        if len(resp) > 0:
            return year

        #check December
        url   = '%s/calendar%s/%d/12' % (URL, _url, year)
        resp  = eval(common.GetHTML(url))
        if len(resp) > 0:
            return year

    return current


def GetRandomMonth(_url, year):
    now     = datetime.datetime.today()
    current = now.month

    months = range(1, 13)
    random.shuffle(months)
    
    for month in months:
        url   = '%s/calendar%s/%d/%d' % (URL, _url, year, month)
        resp  = eval(common.GetHTML(url))
        if len(resp) > 0:
            return month

    return current


def GetRandomDay(_url, year, month):
    now     = datetime.datetime.today()
    current = now.day

    url   = '%s/calendar%s/%d/%d' % (URL, _url, year, month)
    resp  = eval(common.GetHTML(url))

    if len(resp) > 0:
        random.shuffle(resp)      
        day = int(resp[0].split('/')[-1])
        return day
    
    return current    

def AddSection(name, url):
    AddDir(name, SECTION, url, image=os.path.join(ARTWORK, url+'.png'))


def AddCharacter(name, url, image):
    AddDir(name, CHARACTER, url, image, isFolder=False)


def AddDir(name, mode, url='', image=None, isFolder=True, page=1, keyword=None, infoLabels=None, contextMenu=None):

    name = Clean(name)

    if not image:
        image = ICON

    u  = sys.argv[0] 
    u += '?mode='  + str(mode)
    u += '&title=' + urllib.quote_plus(name)
    u += '&image=' + urllib.quote_plus(image)
    u += '&page='  + str(page)

    if url != '':     
        u += '&url='   + urllib.quote_plus(url) 

    if keyword:
        u += '&keyword=' + urllib.quote_plus(keyword) 

    liz = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)

    if contextMenu:
        liz.addContextMenuItems(contextMenu)

    if infoLabels:
        liz.setInfo(type="Video", infoLabels=infoLabels)


    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
           params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param


params = get_params()
mode   = None
url    = None

try:    mode = int(urllib.unquote_plus(params['mode']))
except: pass

try:    url   = urllib.unquote_plus(params['url'])
except: pass


if mode == SECTION:
    Section(url)

elif mode == CHARACTER:
    Character(url)

else:
    Main()

        
try:
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
except:
    pass


 
