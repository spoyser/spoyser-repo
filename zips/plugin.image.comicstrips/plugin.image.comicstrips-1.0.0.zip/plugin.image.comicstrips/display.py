
import xbmcgui
import xbmc
import xbmcaddon
import re
import common


ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10
ACTION_BACK          = 92

ACTION_LEFT  = 1
ACTION_RIGHT = 2
ACTION_UP    = 3
ACTION_DOWN  = 4


ADDONID  = 'plugin.image.comicstrips'
ADDON    = xbmcaddon.Addon(ADDONID)
URL      = 'http://www.gocomics.com'


class Display(xbmcgui.WindowXMLDialog):
    def __new__(cls, url):
        return super(Display, cls).__new__(cls, 'main.xml', ADDON.getAddonInfo('path'))


    def __init__(self, url): 
        super(Display, self).__init__()
        self.url = url


    def onInit(self):
        self.STRIP  = 5001
        self.Clear()

        self.UpdateImage(self.url)


    def Clear(self):
        self.title    = ''
        self.image    = None
        self.previous = None
        self.next     = None
        self.author   = ''
        self.date     = ''

              
    def OnClose(self):
        self.close()


    def onAction(self, action):
        actionID = action.getId()
        buttonID = action.getButtonCode()

        if actionID in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.OnClose()

        if actionID in [ACTION_LEFT, ACTION_UP]:
            if self.previous:
                self.UpdateImage(URL + self.previous)

        if actionID in [ACTION_RIGHT, ACTION_DOWN]:
            if self.next:
                self.UpdateImage(URL + self.next)
            
                                 
    def onClick(self, controlId):
        pass


    def UpdateImage(self, url):
        self.Clear()
        html  = common.GetHTML(url)
        html  = html.replace('\n', '')
        html  = html.split('<p >')[-1]
        match = re.compile('(.+?)</p>.+?<img alt=".+?" src="(.+?)".+?<strong>(.+?)</strong>(.+?)</span>').findall(html)

        self.title  = match[0][0]
        self.image  = match[0][1]
        self.author = match[0][2]
        self.date   = match[0][3]

        if 'revious' in html:
           self.previous = re.compile('<span class="archiveText"><a href="(.+?)">&lt').search(html).groups(1)[0]

        if 'ext &gt' in html:
           self.next = re.compile('<span class="archiveText"><a href=".+?">&lt.+?<a href="(.+?)"').search(html).groups(1)[0]
        
        if self.image:
            self.setControlImage(self.STRIP, self.image)
        

    def setControlImage(self, id, image):
        if image == None:
            return

        try:    self.getControl(id).setImage(image)
        except: pass