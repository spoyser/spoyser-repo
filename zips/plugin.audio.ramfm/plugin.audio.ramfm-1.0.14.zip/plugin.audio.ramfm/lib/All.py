#
#  Copyright (C) 2013
#  Sean Poyser (seanpoyser@gmail.com
#
#  This Program IS NOT released under the GNU General Public License
#
#  If you would like to use this Program in full or any part thereof
#  please contact me at the email address above before use
#
#  This file is necessary to create the 'All' option in the addon settings


def GetImages(artist):
    return []