#
#  Copyright (C) 2013
#  Sean Poyser (seanpoyser@gmail.com)
#
#  If you would like to use this Program in full or any part thereof
#  please contact me at the email address above before use#     
#
#  The code was originally inspired by the XBMC Last.FM - SlideShow by divingmule
#  (script.image.lastfm.slideshow) originally released under the GNU General Public License
#

import urllib
import urllib2
import os
import xbmcaddon

import random
import re


if sys.version_info >=  (2, 7):
    import json
else:
    import simplejson as json 


ADDON = xbmcaddon.Addon(id='plugin.audio.ramfm')
HOME  = ADDON.getAddonInfo('path')

libPath = os.path.join(HOME, 'lib')
sys.path.insert(0, libPath)

scraper  = ['allmusic', 'fanarttv', 'htbackdrops', 'theaudiodb']
scrapers = map(__import__, scraper)

GetString = ADDON.getLocalizedString

icon   = xbmc.translatePath(os.path.join( HOME, 'talk.png'))

def Start():
    if not xbmc.Player().isPlayingAudio():
        xbmc.executebuiltin("XBMC.Notification("+GetString(30000)+","+GetString(30001)+",5000,"+icon+")")      
        return Reset()

    artist = GetArtist()

    Initialise()

    while True:
        xbmc.sleep(1000)
        if artist != GetArtist():
            break

    Start()


def Reset():
    players = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'))
    for player in players['result']:
        if player['type'] == 'picture':
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.Stop", "params": {"playerid":%i}, "id": 1}' % player['playerid'])
        else:
            continue

    xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": {"playlistid":2}, "id": 1}')
    return []


def AddImages(images):
    items =[]
    for image in images:
        if '\'' in image:
            continue
        image = urllib.unquote_plus(image)    
        item  = '{ "jsonrpc": "2.0", "method": "Playlist.Add", "params": { "playlistid": 2 , "item": {"file": "%s"} }, "id": 1 }' % image
        try:    items.append(item.encode('ascii'))
        except: pass    

    print 'Adding - %s images' %str(len(items))
    if len(items) > 0:
        xbmc.executeJSONRPC(str(items).replace("'",""))


def GetImages(artist):
    images = []
    try:        
        source = int(ADDON.getSetting('TALKSHOW')) -1

        if source < 0:
            for i in range(0, len(scrapers)):
                images += scrapers[i].GetImages(artist)
        else:
            images += scrapers[source].GetImages(artist)

    except Exception, e:
        print 'Error in GetImages'
        print str(e)
        xbmc.executebuiltin("XBMC.Notification("+GetString(30000)+","+GetString(30003)+",10000,"+icon+")")
        Reset()

    print 'Total number of images found = %d' % len(images)
    random.shuffle(images)
    #print images
    return images


def Initialise():
    artist = GetArtist()

    print "Initialising slideshow for %s" % artist

    xbmc.executebuiltin("XBMC.Notification("+GetString(30000)+","+GetString(30004)+artist.replace(',', '')+",5000,"+icon+")")
        
    u_artist = artist.upper().replace(' & ',' ').replace(',','').replace('(','').replace(' ) ','').replace(' ','+')

    #if u_artist != 'THE+THE' and u_artist != 'THE':
    #    u_artist = u_artist.replace('THE', '')

    images = GetImages(u_artist)
    if not ShowImages(images):
        xbmc.executebuiltin("XBMC.Notification("+GetString(30000)+","+GetString(30002)+artist+",5000,"+icon+")")
        Reset()

        
def ShowImages(images):    
    if len(images) == 0:
        return False

    Reset()
    if len(images) > 2:
        AddImages(images[:2])
    else:
        AddImages(images)

    playlist = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.GetItems", "params": {"playlistid":2}, "id": 1}'))
    if playlist['result']['limits']['total'] > 1:
        play = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Player.Open","params":{"item":{"playlistid":2}} }')

    if len(images) > 2:
        AddImages(images[2:])

    playlist = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.GetItems", "params": {"playlistid":2}, "id": 1}'))
    if playlist['result']['limits']['total'] > 0:
        players = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'))
        found = False

        for i in players['result']:
            if i['type'] == 'picture':
                found = True
            else: continue

        if not found:
            play = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Player.Open","params":{"item":{"playlistid":2}} }')

    return True
        


def GetArtist():
    artist = ''

    try:
        artist = xbmc.Player().getMusicInfoTag().getArtist()
    except:
        #try again in a second
        xbmc.sleep(1000)
        try:    artist = xbmc.Player().getMusicInfoTag().getArtist()
        except: pass

    if len(artist) < 1:        
        try:    artist = xbmc.Player().getMusicInfoTag().getTitle().split(' - ')[0]
        except: pass

    return artist


if __name__ == '__main__':  
    Start()