#
#  Copyright (C) 2013
#  Sean Poyser (seanpoyser@gmail.com
#
#  This Program IS NOT released under the GNU General Public License
#
#  If you would like to use this Program in full or any part thereof
#  please contact me at the email address above before use
#

import urllib2
import sys
import re

if sys.version_info >=  (2, 7):
    import json
else:
    import simplejson as json


ROOT   = 'http://www.theaudiodb.com/api/v1/json/'
API    = '58424d43204d6564696120'
SEARCH = ROOT + API + '/search.php?s='
NAME   = 'TheAudio.DB'


def GetHTML(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Apple-iPhone/')
    response = urllib2.urlopen(req)
    html = response.read()
    response.close()
    return html


def GetImages(artist):
    images = DoGetImages(artist)

    if len(images) > 0:
        return images

    reverse = ''
    split   = artist.split('+')
    for item in split:
        reverse = item + '+' + reverse
    reverse = reverse[:-1]

    return DoGetImages(reverse)


def DoGetImages(artist):
    try:
        url = SEARCH + artist

        images = []

        print NAME + ' 1st URL requested: %s' % url           
        link = GetHTML(url)
        link = link.replace(',',  '\n')

        matchJPG = re.compile('http(.+?).jpg').findall(link)
        #matchPNG = re.compile('http(.+?).png').findall(link)

        for img in matchJPG:
            img = 'http' + img + '.jpg'
            images.append(img)

        #for img in matchPNG:
        #    img = 'http' + img + '.png'
        #    images.append(img)

    except Exception, e:
        print str(e)

    print NAME + ' Found - %d images' % len(images)
    return images