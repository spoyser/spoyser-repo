#
#  Copyright (C) 2013
#  Sean Poyser (seanpoyser@gmail.com
#
#  This Program IS NOT released under the GNU General Public License
#
#  If you would like to use this Program in full or any part thereof
#  please contact me at the email address above before use
#

import urllib2
import re

ROOT = 'http://www.allmusic.com/artist/'
NAME = 'All.Music'


def GetImages(artist):
    if artist == '':
        return []

    artist = artist.upper().replace(' & ',' ').replace(',','+').replace('(','').replace(')','').replace(' ','+')
    artist = artist.replace('++', '+')

    images = []

    try:        
        url = GetURL(artist)

        print NAME + ' 2nd URL requested: %s' % url

        if url != '':
            link = GetHTML(url)
            link = link.replace('\n', '')

            #image1 = re.compile('<meta name="image" content="(.+?).jpg').search(link).group(1)
            #images.append(image1+'.jpg')

            gallery = link.split('Photo Gallery', 1)[1]
            gallery = gallery.split('<span class', 1)[0]
            gallery = gallery.replace('_jpg', '*j*p*g')

            match   = re.compile('<img src="(.+?).jpg').findall(gallery)
            for img in match:
                #if 'cps-static.rovicorp.com/3' in img:
                if 'rovi' in img:                
                    img   = img.replace('*j*p*g', '_jpg')
                    img = img.replace('170', '500')
                    images.append(img+'.jpg')

    except Exception, e:
        pass

    print NAME + ' Found - %d images' % len(images)
    return images


def GetURL(artist):
    try:
        reverse = ''
        split   = artist.split('+')
        for item in split:
            reverse = item + reverse
        forward = artist.replace('+', '')

        #NB forward and reverse DO NOT contain any '+'

        url = 'http://www.allmusic.com/search/artists/' + artist
   
        print NAME + ' 1st URL requested: %s' % url           
        link = GetHTML(url)

        match = re.compile(ROOT+'(.+?)" data-tooltip.+?}">(.+?)</a>').findall(link)
        for url, artist in match:
            artist = artist.replace(' ', '').upper()
            if (forward in artist) or (reverse in artist):
                return ROOT + url

        #all else fails, just return the first one
        return ROOT + match[0][0]

    except Exception, e:
        print str(e)    

    return ''


def GetHTML(url):
    req = urllib2.Request(url)
    #req.add_header('User-Agent', 'Apple-iPhone/')
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Referer',    'http://www.allmusic.com/')


    response = urllib2.urlopen(req)
    html     = response.read()

    response.close()
    return html