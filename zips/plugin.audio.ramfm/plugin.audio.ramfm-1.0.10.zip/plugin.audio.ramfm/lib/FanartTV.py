#
#  Copyright (C) 2013
#  Sean Poyser (seanpoyser@gmail.com
#
#  This Program IS NOT released under the GNU General Public License
#
#  If you would like to use this Program in full or any part thereof
#  please contact me at the email address above before use
#

import urllib2
import re

ROOT = 'http://fanart.tv/'
NAME = 'Fanart.TV'

def GetImages(artist):
    artist = artist.upper().replace(' & ',' ').replace(',','+').replace('(','').replace(')','').replace(' ','+')
    artist = artist.replace('++', '+')

    try:
        url    = ROOT + 'api/getdata.php?type=2&s=' + artist
        images = []

        print NAME + ' 1st URL requested: %s' % url
        link = GetHTML(url)

        max = -1
        url = None

        match = re.compile('<div class="item-name"><a href="/(.+?)".+?<span class="pop">(.+?)</span>').findall(link)
        for link, qty in match:
            qty = int(qty)
            if max < qty:
                max = qty
                url = link

        if not url:
            return images

        url = ROOT + url
    
        print NAME + ' 2nd URL requested: %s' % url
        link = GetHTML(url)

        match = re.compile('href="/(.+?).jpg"').findall(link)

        for img in match:
            images.append(ROOT+img+'.jpg')

    except Exception, e:
        print str(e)

    print NAME + ' Found - %d images' % len(images)
    return images


def GetHTML(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Apple-iPhone/')

    response = urllib2.urlopen(req)
    html     = response.read()

    response.close()
    return html